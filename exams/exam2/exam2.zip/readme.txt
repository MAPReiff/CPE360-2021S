I pledge my honor that I have abided by the Stevens Honor System

I could not fit all of the functions into 1 screenshot, so I have included a multi page PDF with screenshots for each question.
